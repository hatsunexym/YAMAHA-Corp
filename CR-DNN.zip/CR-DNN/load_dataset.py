# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 15:01:03 2019

@author: Youmin
"""
import numpy as np
import pandas as pd

'''
读取CSV文件，里面存储了每一个处理好的数据
'''
csv_dataset = pd.read_csv('C:/Users/Youmin/Desktop/train_data.csv')


'''
循环读取每一个数据
'''
data = []
label = []
for i in range(len(csv_dataset)):
    data_ = np.loadtxt('C:/Users/Youmin/Desktop/fortepianoise/'+str(a['label'][0])+'/'+str(a['fileroot'][0])).reshape([-1])