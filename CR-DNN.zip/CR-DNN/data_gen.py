# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 15:27:50 2019

@author: Youmin
"""

'''
*before using this .py file, please check the path you want to load and generate.

    This is the code to generate the dataset by using MFCC[128, X]. 
    X is the median value of frame in the whole original dataset. 

    wave_data_generate(): Generate features by using MFCC
    data_reshape(): Choose the median value to reshape the sequence into [128, median] by cutting or 0-padding.
    data_preprocessing(path,wave_before,wave_after): label the reshaped data then shuffle them and finally save to json
    
    load the dataset by using command : dataset = pd.read_json('C:/Users/Youmin/Desktop/Rhodes/data.json')
    
'''
import os
import numpy as np
import pandas as pd
import librosa as lr
import time

# MFCC features generator
def wave_data_generate(path):
    filelist = os.listdir(path)
    feature_list = []
    for file in filelist:
        file.replace("\\","/")
        file_dir = os.path.join(path,file)
        y, sr= lr.load(file_dir, sr=None)   # y is audio time series, sr is sampling rate of y
        
        # extract mel spectrogram feature
        melspec = lr.feature.melspectrogram(y, sr, n_fft=1024, hop_length=512, n_mels=32)  
        # here n_fft is the size of window,hop_length is the distance between each window(here means 1/2 overlap), n_mels is the number of mel bands
        
        # convert to log scale
        logmelspec = lr.power_to_db(melspec)
        # shape of logmelspec is (a,b), a is the dimension of mel-frequency and b is the lenth of frames(times) 
        feature_list.append(logmelspec)
        #time.append(time_data)
    return feature_list

# Feature reshape function
def data_reshape(x):
    
    # get the median value as the reshape sizeX
    list_y = []
    for j in range(0,len(x)):
        list_y.append(np.shape(x[j])[1])
        midvalue = int(np.median(list_y))
        
    # do if selection to judge whether it needs 0-padding
    for i in range(0,len(x)):
        if np.shape(x[i])[1] >= midvalue:   
            x[i] = x[i][:,:midvalue]
        else:# Doing 0-padding operations on the matrixs whose length is less than median
            x[i] = np.pad(x[i],((0,0),(0,midvalue-np.shape(x[i])[1])),'constant',constant_values = (0,0))
        x[i] = x[i].reshape([-1])
        x[i] = x[i].reshape([-1,len(x[i])])
    return x

#     Data pre-processing：define the label & shuffle
def data_preprocessing(path,wave_before,wave_after):
    from sklearn.utils import shuffle
    before_data = {'vector':wave_before.tolist()}
    before_data = pd.DataFrame(before_data)
    before_data['label'] = '0'
    
    after_data = {'vector':wave_after.tolist()}
    after_data = pd.DataFrame(after_data)
    after_data['label'] = '1'
    # concat noise & denoised
    train_data = pd.concat([before_data,after_data],axis=0)
    # shuffle
    train_data = shuffle(train_data)
    train_data.index = range(len(train_data))
    path = path+'/data.json'
    path = path.replace("\\","/")
    
    
    # save as json
    #train_data.to_csv(path)
    train_data.to_json(path)
    return train_data # here the output data has index which could be ignored

def sli_win(x): 
    for i in range(len(x)):
        mfcc_num = np.shape(x[i])[0]
        length = np.shape(x[i])[1]
        num_window = int(np.floor(length/mfcc_num))#each window has a same size of 32x32
        x[i] = np.array([x[i][:,j*32:(j+1)*32] for j in range(num_window)]).reshape([-1,1024])
    x = np.vstack(x)
    return x


def main(path,path_before,path_after):
    start = time.clock()
    # Output the generated MFCC features
    before = wave_data_generate(path_before)
    after = wave_data_generate(path_after)
    
    # Step2:
    # Feature reshape,into[-1]
#    wave_before = data_reshape(before)
#    wave_after = data_reshape(after)
    wave_before = sli_win(before)
    wave_after = sli_win(after)
    data_preprocessing(path,wave_before,wave_after)
    end = time.clock()
    time_cost = end - start
    return time_cost
    

# Start
# Change the root of path to generate the MFCC feature of Audio-sequences
# Hint: here we need to input a pair of dataset, both the original and denoised sequences.
    # Piano
path_before = "C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_Before"
path_after = "C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_After"
path_generated = 'C:/Users/Youmin/Desktop/fortepianoise'

#    # MFK
#path_before = "C:/Users/Youmin/Desktop/19MFK/19MFK/HissReduction_Before"
#path_after = "C:/Users/Youmin/Desktop/19MFK/19MFK/HissReduction_After"
#path_generated = 'C:/Users/Youmin/Desktop/MFK'

#    #CFX
#path_before = "C:/Users/Youmin/Desktop/1704CFX/1704CFX/HissReduction_before"
#path_after = "C:/Users/Youmin/Desktop/1704CFX/1704CFX/HissReduction_After"
#path_generated = 'C:/Users/Youmin/Desktop/CFX'

    #Rhodes
#path_before = "C:/Users/Youmin/Desktop/Rhodes_noise/HissReduction_before"
#path_after = "C:/Users/Youmin/Desktop/Rhodes_noise/HissReduction_after"
#path_generated = 'C:/Users/Youmin/Desktop/Rhodes'



    
if input('Start to generate the features and save it into the .json file. The root to save is Desktop.'
      'If everything is okay, please click the enter to continue.......'+'\n') == '':
    print('Started feature generating.........'
          'please hold on.........'+'\n')
    print('time cost:', main(path_generated,path_before,path_after))
    print('\n'+'finished'+'\n')
else:
    print('Error')



