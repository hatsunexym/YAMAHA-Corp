# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 15:27:50 2019

@author: Youmin
"""

'''

    本代码第一部分：
    wave_data_generate实现MFCC对音频序列特征的粗提取,提取后维度为[128,X]
    
    第二部分：
    因为经过wave_data_generate出来的音频序列长度不匹配，size不一致
    考虑使用data_reshape函数对sequence进行裁剪crop操作，这里采用中值取数-0填充裁剪法
    *Hint：因为针对的噪音不同，不同数据集采用的中位数裁剪法没办法普适于所有数据，因此每一种噪音都将重新resize CNN 1st layer的kernel大小
    
    
    第三部分：
    将数据处理为pandas的表格，并为每一个数据MFCC特征打上标签
    0: original data
    1: denoised data
    并且对处理后的数据进行整合，shuffle打乱顺序后存储为该音频文件的数据集
'''
import os
import numpy as np
import pandas as pd
import librosa as lr
import time

# MFCC features generator
def wave_data_generate(path):
    filelist = os.listdir(path)
    feature_list = []
    for file in filelist:
        file.replace("\\","/")
        file_dir = os.path.join(path,file)
        y, sr= lr.load(file_dir, sr=None)   # y is audio time series, sr is sampling rate of y
        
        # extract mel spectrogram feature
        melspec = lr.feature.melspectrogram(y, sr, n_fft=1024, hop_length=512, n_mels=128)  
        # here n_fft is the size of window,hop_length is the distance between each window(here means 1/2 overlap), n_mels is the number of mel bands
        
        # convert to log scale
        logmelspec = lr.power_to_db(melspec)
        # shape of logmelspec is (a,b), a is the dimension of mel-frequency and b is the lenth of frames(times) 
        feature_list.append(logmelspec)
        #time.append(time_data)
    return feature_list

# Feature reshape function
def data_reshape(x):
    
    # get the median value as the reshape sizeX
    list_y = []
    for j in range(0,len(x)):
        list_y.append(np.shape(x[j])[1])
        midvalue = int(np.median(list_y))
        
    # do if selection to judge whether it needs 0-padding
    for i in range(0,len(x)):
        if np.shape(x[i])[1] >= midvalue:   
            x[i] = x[i][:,:midvalue]
        else:# Doing 0-padding operations on the matrixs whose length is less than median
            x[i] = np.pad(x[i],((0,0),(0,midvalue-np.shape(x[i])[1])),'constant',constant_values = (0,0))
        x[i] = x[i].reshape([-1])
        x[i] = x[i].reshape([-1,len(x[i])])
    return x

#     Data pre-processing：define the label & shuffle
def data_preprocessing(path,wave_before,wave_after):
    from sklearn.utils import shuffle
    before_data = {'vector':wave_before}
    before_data = pd.DataFrame(before_data)
    before_data['label'] = '0'
    
    after_data = {'vector':wave_after}
    after_data = pd.DataFrame(after_data)
    after_data['label'] = '1'
    # 合并噪声与非噪声数据
    train_data = pd.concat([before_data,after_data],axis=0)
    # 对训练数据打乱顺序
    train_data = shuffle(train_data)
    train_data.index = range(len(train_data))
    path = path+'/data.json'
    path = path.replace("\\","/")
    
    
    #将数据集作为json格式保存到path下
    train_data.to_json(path)
    return train_data # here the output data has index which could be ignored


def main(path,path_before,path_after):
    start = time.clock()
    # Output the generated MFCC features
    before = wave_data_generate(path_before)
    after = wave_data_generate(path_after)
    
    # Step2:
    # Feature reshape,into[-1]
    wave_before = data_reshape(before)
    wave_after = data_reshape(after)
    data_preprocessing(path,wave_before,wave_after)
    end = time.clock()
    time_cost = end - start
    return time_cost
    

# Start
# Change the root of path to generate the MFCC feature of Audio-sequences
# Hint: here we need to input a pair of dataset, both the original and denoised sequences.
path_before = "C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_Before"
path_after = "C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_After"
path_generated = 'C:/Users/Youmin/Desktop/fortepianoise'



if input('Start to generate the features and save it into the .json file. The root to save is Desktop.'
      'If everything is okay, please click the enter to continue.......'+'\n') == '':
    print('Started feature generating.........'
          'please hold on.........'+'\n')
    print('time cost:', main(path_generated,path_before,path_after))
    print('\n'+'finished'+'\n')
else:
    print('Error')







 
## HDF5的读取：
#f = h5py.File('HDF5_FILE.h5', 'r')   # 打开h5文件
#data = f['data'][:]   # 取出主键为data的所有的键值
#labels = f['labels'][:]   # 取出主键为labels的所有的键值
#f.close()


