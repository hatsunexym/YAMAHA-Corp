# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 11:38:17 2019

@author: Youmin
"""
import librosa as lr
import pandas as pd
import numpy as np
#get_ipython().magic('matplotlib inline')

from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
import keras
import warnings
from keras import models
from keras import layers



warnings.filterwarnings('ignore')
# Analysing the Data in Pandas
# coding: utf-8
def main(data):
    #data = pd.read_csv('C:/Users/Youmin/Desktop/audio_processing/dataRhodes.csv')
    #data = shuffle(data)
    #data.index = range(len(data))
    data = pd.read_csv(data)
    data.head()
    data.shape
    
    # Dropping unneccesary columns
    data_noname = data.drop(['filename'],axis=1)
    
    # Encoding the Labels
    genre_list = data_noname.iloc[:, -1]
    encoder = LabelEncoder()
    y = encoder.fit_transform(genre_list)
    
    # Scaling the Feature columns
    scaler = StandardScaler()
    X = scaler.fit_transform(np.array(data_noname.iloc[:, :-1], dtype = float))
    
    # Dividing data into training and Testing set
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)
    
    #len(y_train)
    #len(y_test)
    #X_train[10]
    
    # Classification with Keras
    # Building our Network
    
    
    '''
    #
    model = models.Sequential()
    model.add(layers.Dense(256, activation='relu', input_shape=(X_train.shape[1],)))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(32, activation='relu'))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dense(1, activation='sigmoid'))
    
    
    sgd = keras.optimizers.SGD(lr=0.01, decay = 1e-6, momentum = 0.9, nesterov = True)
    model.compile(optimizer=sgd,
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    
    history = model.fit(X_train,
                        y_train,
                        epochs=20,
                        batch_size=128)
    
    test_loss, test_acc = model.evaluate(X_test,y_test)
    if __name__ == '__main__':
    data = '/home/youmin/Desktop/dense-dnn/data16Forte.csv'
    model = main(data)[0]
    print('test_acc: ',test_acc)
    
     Tes accuracy is less than training data accuracy. This hints at Overfitting.
    
     Validating our approach
     Let's set apart 200 samples in our training data to use as a validation set:
    '''
    
    x_val = X_train[:20]
    partial_x_train = X_train[20:]
    
    y_val = y_train[:20]
    partial_y_train = y_train[20:]
    
    # Now let's train our network for 20 epochs:
    
    model = models.Sequential()
    model.add(layers.Dense(512, activation='relu', input_shape=(X_train.shape[1],)))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(256, activation='relu'))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(32, activation='relu'))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dense(1, activation='sigmoid'))
    
    sgd = keras.optimizers.SGD(lr=0.01, decay = 1e-6, momentum = 0.9, nesterov = True)
    
    model.compile(optimizer=sgd,
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    
    model.fit(partial_x_train,
              partial_y_train,
              epochs=50,
              batch_size=512,
              validation_data=(x_val, y_val))
    
    results = model.evaluate(X_test, y_test)
    
    results
    
    # Predictions on Test Data
    predictions = model.predict(X_test)
    
    predictions[0].shape
    
    np.sum(predictions[0])
    
    np.argmax(predictions[0])
    
    
    for i in range(len(predictions)):
        if predictions[i]>0.5:
            predictions[i]=1
        else:predictions[i]=0
    acc = sum(predictions==y_test.reshape([-1,1]))*100/len(predictions)
    print('the accuracy is %.2f %%' %acc)
    return model,np.array(data_noname.iloc[:, :-1],dtype=float)

