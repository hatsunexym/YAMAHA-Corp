# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 11:02:14 2019

@author: Youmin
"""

# 特征提取和数据预处理
import librosa as lr
import numpy as np
import matplotlib.pyplot as plt
#get_ipython().magic('matplotlib inline')
import os
import pathlib
import csv


import warnings
warnings.filterwarnings('ignore')

###############################################################################
'''
first step: extract spec img from the audio file

output: root & categories
'''
#path = 'C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_After'
#data_generated(path,'after')


cmap = plt.get_cmap('inferno')

plt.figure(figsize=(10,10))
labels = 'before after'.split()
for g in labels:
    pathlib.Path(f'img_data/{g}').mkdir(parents=True, exist_ok=True) 
    #path = f'C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_{g}'
    #path = f'C:/Users/Youmin/Desktop/1704CFX/1704CFX/HissReduction_{g}'
    path = f'C:/Users/Youmin/Desktop/Rhodes_noise/HissReduction_{g}'
    for file in os.listdir(path):
        file.replace("\\","/")
        file_dir = f'{path}/{file}'
        y, sr = lr.load(file_dir, mono=True, duration=5)
        #NFFT: points number of FFT
        plt.specgram(y, NFFT=2048, Fs=2, Fc=0, noverlap=128, cmap=cmap, sides='default', mode='default', scale='dB');
        plt.axis('off');
        plt.savefig(f'img_data/{g}/{file[:-3].replace(".", "")}.png')
        plt.clf()

      
    
'''
Features:
    
Mel-frequency cepstral coefficients (MFCC)(20 in number)
Spectral Centroid,
Zero Crossing Rate
Chroma Frequencies
Spectral Roll-off.
'''

header = 'filename chroma_stft rmse spectral_centroid spectral_bandwidth rolloff zero_crossing_rate'
for i in range(1, 21):
    header += f' mfcc{i}'
header += ' label'
header = header.split()
filelist = os.listdir(path)
doc = open('data.csv', 'w', newline='')
with doc:
    writer = csv.writer(doc)
    writer.writerow(header)
labels = 'before after'.split()
for g in labels:
    #path_ = f'C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_{g}'
    #path_ = f'C:/Users/Youmin/Desktop/1704CFX/1704CFX/HissReduction_{g}'
    path_ = f'C:/Users/Youmin/Desktop/Rhodes_noise/HissReduction_{g}'
    for filenames in os.listdir(path_):
        filenames.replace("\\","/")
        file_dir2 = f'{path_}/{filenames}'
        y, sr = lr.load(file_dir2, mono=True, duration=30)
        chroma_stft = lr.feature.chroma_stft(y=y, sr=sr)
        rmse = lr.feature.rmse(y=y)
        spec_cent = lr.feature.spectral_centroid(y=y, sr=sr)
        spec_bw = lr.feature.spectral_bandwidth(y=y, sr=sr)
        rolloff = lr.feature.spectral_rolloff(y=y, sr=sr)
        zcr = lr.feature.zero_crossing_rate(y)
        mfcc = lr.feature.mfcc(y=y, sr=sr)
        to_append = f'{filenames} {np.mean(chroma_stft)} {np.mean(rmse)} {np.mean(spec_cent)} {np.mean(spec_bw)} {np.mean(rolloff)} {np.mean(zcr)}'    
        for e in mfcc:
            to_append += f' {np.mean(e)}'
        to_append += f' {g}'
        doc = open('data.csv', 'a', newline='')
        with doc:
            writer = csv.writer(doc)
            writer.writerow(to_append.split())
#path = 'C:/Users/Youmin/Desktop/16FortePiano/16FortePiano/HissReduction_After'
#data_generated(path,'after')

