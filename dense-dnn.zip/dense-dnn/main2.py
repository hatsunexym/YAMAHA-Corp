#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 11:05:20 2019

@author: youmin
"""
from keras_model import main
from feature_extract import fea_ex
from sklearn.preprocessing import StandardScaler
import numpy as np
import sys


def pred(filename, data):
    test = fea_ex(filename)
    model,X = main(data)
    X = np.r_[X,test]
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    test = X[-1,:].reshape(1,-1)
    res = model.predict(test)
    if res > 0.5:
        print('predict value = ',res[0],'it is a noise file')
    else:
        print('predict value = ',res[0],'it is a clean file')

if __name__ == '__main__':
    pred(sys.argv[1], sys.argv[2])
