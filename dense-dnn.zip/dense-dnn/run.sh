#!/bin/bash

TEST_AUDIO="/home/youmin/Desktop/16FortePiano/16FortePiano/HissReduction_After/FP_P_ff_024_h00000.aif"
TRAINING_DATA="/home/youmin/Desktop/dense-dnn/dataset/data16Forte.csv"

echo "INPUT WAV FILE:" $TEST_AUDIO
echo "TRAINING DATA PATH:" $TRAINING_DATA

python3 main2.py $TEST_AUDIO $TRAINING_DATA
