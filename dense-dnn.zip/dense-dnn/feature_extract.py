#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 10:48:34 2019

@author: youmin
"""
import librosa as lr
import numpy as np

def fea_ex(file_dir2):
    header = 'filename chroma_stft rmse spectral_centroid spectral_bandwidth rolloff zero_crossing_rate'
    for i in range(1, 21):
        header += f' mfcc{i}'
    header = header.split()


    y, sr = lr.load(file_dir2, mono=True, duration=30)
    chroma_stft = np.mean(lr.feature.chroma_stft(y=y, sr=sr))
    rmse = np.mean(lr.feature.rmse(y=y))
    spec_cent = np.mean(lr.feature.spectral_centroid(y=y, sr=sr))
    spec_bw = np.mean(lr.feature.spectral_bandwidth(y=y, sr=sr))
    rolloff = np.mean(lr.feature.spectral_rolloff(y=y, sr=sr))
    zcr = np.mean(lr.feature.zero_crossing_rate(y))
    values = [chroma_stft, rmse, spec_cent, spec_bw, rolloff, zcr]
    mfcc = lr.feature.mfcc(y=y, sr=sr)
    for e in mfcc:
        values.append(np.mean(e))
        
    filename = file_dir2.split('/')[-1]
    values = np.array(values).reshape(1,-1)

    return values